Create database RCS;

Use RCS;

Show tables;

Create table Cliente (
   id_cliente Integer Auto_Increment Not Null,
   nome Varchar(100) Not Null,
   email Varchar(100)Not Null,
   telefone Varchar(20) Not Null,
   Primary Key (id_cliente)
) Engine = InnoDB;

Select * From Cliente;

Create table Produto (
    id_produto Integer Auto_Increment Not Null,
    nome Varchar (100) Not Null,
    descricao Varchar(100) Not Null,
    marca Varchar(200) Not Null,
    Primary Key (id_produto)
) Engine = InnoDB;

Select * From Produto;

Create table Funcionario (
    id_funcionario Integer Auto_Increment Not Null,
    nome Varchar (100) Not Null,
    CPF Varchar (14) Not Null,
    telefone Varchar(20) Not Null,
    cargo Varchar (45) Not Null,
    Primary Key (id_funcionario)
) Engine = InnoDB;

Select * From Funcionario;

Create table Item_Defeito (
   id_item Integer Auto_Increment Not Null,
   nome Varchar (100) Not Null,
   descricao Varchar(200) Not Null,
   marca Varchar(45) Not Null,
   Primary Key (id_item)
)Engine = InnoDB;

Select * From Item_Defeito;

Create table Nota_Compra (
    id_compra Integer Auto_Increment Not Null,
    id_cliente Int Not Null,
    id_produto Int Not Null,
    quantidade Int Not Null,
	hora Time,
    data_ Date,
    valor Decimal (6,2) Not Null,
    Primary Key (id_compra),
    Foreign Key (id_cliente) references Cliente(id_cliente),
    Foreign Key (id_produto) references Produto(id_produto)
) Engine = InnoDB;

Select * From Nota_Compra;
Drop table Nota_Compra;

Create table Pedido (
    id_pedido Integer Auto_Increment Not Null,
    id_cliente Int Not Null,
    id_funcionario Int Not Null,
    id_item Int Not Null,
    diagnostico Varchar (200) Not Null,
    Primary Key (id_pedido),
    Foreign Key (id_cliente) references Cliente (id_cliente),
    Foreign Key (id_funcionario) references Funcionario(id_funcionario),
    Foreign Key (id_item) references Item_Defeito(id_item)
) Engine = InnoDB;

Select * From Pedido;

Create table Ordem_Servico (
    id_servico Integer Auto_Increment Not Null,
    id_pedido Int Not Null,    
    data_de_entrada Date,
    previsao_de_entrega Date,
    Primary Key (id_servico),
    Foreign Key (id_pedido) references Pedido (id_pedido)
) Engine = InnoDB;

Select * From Ordem_Servico;

Create table Estoque_Produto (
    id_estoquePR Integer Auto_Increment Not Null,
    id_servico Int Not Null,
    quantidade Int Not Null,
    Primary Key (id_estoquePR),
    Foreign Key (id_servico) references Ordem_Servico (id_servico)
)Engine = InnoDB;

Select * From Estoque_Produto;

Create table Estoque_Servico (
    id_estoqueSE Integer Auto_Increment Not Null,
    id_item Int Not Null,
    quantidade Int Not Null,
    status_ Varchar(10),
    Primary Key (id_estoqueSE),
    Foreign Key (id_item) references Item_Defeito(id_item)
) Engine = InnoDB;

Select * From Estoque_Servico;


Set SQL_Safe_Updates = 0;
