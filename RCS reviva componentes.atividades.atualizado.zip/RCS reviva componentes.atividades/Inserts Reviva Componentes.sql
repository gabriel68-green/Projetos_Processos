Use RCS;

Insert Into Cliente (id_cliente, nome, email, telefone)
Values (Null, 'José Amanco', 'joseamanco60@gmail.com', '4556662351'),
(Null, 'Maria Musa', 'musarainha55@gmail.com', '2190612310'),
(Null, 'Helena de Troia', 'helenaproblema0@gmail.com', '8966512452'),
(Null, 'Luís Forge', 'luiscarroslegais71@gmail.com', '7896308520'),
(Null, 'Loona Campos', 'loonaamaislinda@gmail.com', '4985206417');

Select * From Cliente;

Insert Into Produto (id_produto, nome, descricao, marca)
Values(Null, 'Líquidificador', 'eletrodoméstico para processar alimentos em líquido','Philips'),
(Null, 'Rádio Bluetooth', 'eletrônico para lazer e informação sonora','Philco'),
(Null, 'Sandwicheira', 'eletrodoméstico para prensar e esquentar alimentos montados como o sandwiche','Britania'),
(Null, 'Caixa de Som', 'eletrónico para alto alcance de distancia para propagar o som','Sony'),
(Null, 'Placa Mãe', 'Hardware que centraliza e conecta todas as peças do computador de forma lógica','MSI');

Select * From Produto;

Insert Into Funcionario (id_funcionario, nome, CPF, telefone, cargo)
Values(Null, 'Argélio Cobra', '566120390-45', '8950126399', 'Técnico Eletrônico'),
(Null, 'Roberto Santos', '890233566-10', '1056301289', 'Técnico Eletrônico'),
(Null, 'Andreia Silva', '233506902-70', '5689692310', 'Vendedora');

Select * From Funcionario;

Insert Into Item_Defeito (id_item, nome, descricao, marca)
Values(Null, 'Vitrola Eletrônica', 'o som para de sair depois de 20 minutos tocando', 'Raveo'),
(Null, 'Placa de video GTX 1650 4GB', 'já foi testada lógicamente e o problema está no 
consumo de energia direto do hardwarer', 'MSI'),
(Null, 'Ar Condicionado', 'depois de uns minutos que refrigera o ar começa a fazer barulhos estranhos', 'LG'),
(Null, 'Carrinho de Controle Remoto', 'o carrinho não anda, pilhas foram trocadas e o 
controle liga, menos o carrinho', 'Multitrust');

Select * From Item_Defeito;

Insert Into Nota_Compra (id_compra, id_cliente, id_produto, quantidade, hora, data_, valor)
Values (Null, 4, 3, 1, '14:15', '2025-09-07', '68.50'),
(Null, 4, 4, 2, '14:15', '2025-09-07', '422.89'),
(Null, 2, 2, 2, '17:50', '2025-06-10', '205.45'),
(Null, 2, 3, 1, '08:40', '2025-05-01', '68.50'),
(Null, 5, 5, 1, '11:12', '2025-10-30', '325.72'),
(Null, 1, 1, 2, '10:18', '2025-02-22', '258.90'),
(Null, 3, 2, 2, '16:30', '2025-08-09', '137.00'),
(Null, 3, 5, 1, '09:30', '2025-08-01', '325.72'),
(Null, 1, 4, 3, '09:45', '2025-06-10', '634.32');

Select * From Nota_Compra; 

Insert Into Pedido (id_pedido, id_cliente, id_funcionario, id_item, diagnostico)
Value (Null, 1, 2, 3, 'Motor forçando potência'),
(Null, 3, 1, 1, 'Desgate e corrosão na fiação'),
(Null, 5, 2, 2, 'Capacitores desgastados e fiação danificada da ventoinha'),
(Null, 2, 1, 4, 'Mini motor de ignição pifado');

Select * From Pedido;

Insert Into Ordem_Servico (id_servico, id_pedido, data_de_entrada,
previsao_de_entrega)
Value (Null, 1, '2025-07-08', '2025-07-15'),
(Null, 2, '2025-10-09', '2025-10-18'),
(Null, 3, '2025-11-01', '2025-11-10'),
(Null, 4, '2025-02-10', '2025-02-17');

Select * From Ordem_servico;

Insert Into Estoque_Produto (id_estoquePR, id_produto, quantidade)
Value (Null, 1, 15), (Null, 2, 18), (Null, 3, 7), (Null, 4, 5), (Null, 5, 4);

Select * From Estoque_Produto;

Insert Into Estoque_Servico (id_estoqueSE, id_servico, quantidade, status_)
Value (Null, 2, 1, 'reparo'), (Null, 3, 1, 'pronto'), (Null, 1, 1, 'reparo'),
(Null, 4, 1, 'pronto');

Select * From Estoque_Servico;

Delete From Pedido Where id_pedido Between 10 And 18; 
Set SQL_Safe_Updates = 0;

