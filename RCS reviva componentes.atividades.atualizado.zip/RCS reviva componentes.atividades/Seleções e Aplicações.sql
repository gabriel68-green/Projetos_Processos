Use rcs;

Show triggers;

 -- Compras realizadas, com nome do cliente e produto --
SELECT
    C.nome AS Cliente,
    P.nome AS Produto,
    NC.quantidade,
    NC.valor
FROM Nota_Compra NC
INNER JOIN Cliente C ON NC.id_cliente = C.id_cliente
INNER JOIN Produto P ON NC.id_produto = P.id_produto;

-- Pedidos de manutenção e seus respectivos funcionários --
SELECT
    C.nome AS Cliente,
    F.nome AS Funcionario,
    I.nome AS Equipamento,
    P.diagnostico
FROM Pedido P
INNER JOIN Cliente C ON P.id_cliente = C.id_cliente
INNER JOIN Funcionario F ON P.id_funcionario = F.id_funcionario
INNER JOIN Item_Defeito I ON P.id_item = I.id_item;

-- Consultar serviços e suas datas de entrega --
SELECT
    OS.id_servico,
    C.nome AS Cliente,
    OS.data_de_entrada,
    OS.previsao_de_entrega
FROM Ordem_Servico OS
INNER JOIN Pedido P ON OS.id_pedido = P.id_pedido
INNER JOIN Cliente C ON P.id_cliente = C.id_cliente;

-- Consultar produtos com estoque baixo (5 unidades ou menos) --
SELECT
    P.nome AS Produto,
    EP.quantidade
FROM Produto P
INNER JOIN Estoque_Produto EP ON P.id_produto = EP.id_produto
WHERE EP.quantidade <= 5;

-- Descobrir quantos clientes solicitaram serviços de manutenção --
SELECT COUNT(DISTINCT id_cliente) AS Total_Clientes
FROM Pedido;

-- atualizar automaticamente o estoque de produtos --
DROP TRIGGER IF EXISTS Atualizar_Estoque;
DELIMITER //

CREATE TRIGGER Atualizar_Estoque
AFTER INSERT ON Nota_Compra
FOR EACH ROW
BEGIN
    IF EXISTS (
        SELECT 1
        FROM Estoque_Produto
        WHERE id_produto = NEW.id_produto
    ) THEN
        UPDATE Estoque_Produto
        SET quantidade = quantidade + NEW.quantidade
        WHERE id_produto = NEW.id_produto;
    ELSE
        INSERT INTO Estoque_Produto (id_produto, quantidade)
        VALUES (NEW.id_produto, NEW.quantidade);
    END IF;
END //
DELIMITER ;


SELECT
    P.nome AS Produto,
    EP.quantidade AS Quantidade_Estoque
FROM Estoque_Produto EP
INNER JOIN Produto P ON EP.id_produto = P.id_produto
WHERE EP.id_produto = 2;

-- registrar uma nova compra no banco de dados --
DROP PROCEDURE IF EXISTS Registrar_Compra;
DELIMITER //

CREATE PROCEDURE Registrar_Compra (
    IN p_id_cliente INT,
    IN p_id_produto INT,
    IN p_quantidade INT,
    IN p_valor DECIMAL(6,2)
)
BEGIN
    INSERT INTO Nota_Compra (
        id_cliente,
        id_produto,
        quantidade,
        hora,
        data_,
        valor
    )
    VALUES (
        p_id_cliente,
        p_id_produto,
        p_quantidade,
        CURTIME(),
        CURDATE(),
        p_valor
    );
END //
DELIMITER ;

CALL Registrar_Compra(1, 2, 3, 100.00);
CALL Registrar_Compra(1, 2, 5, 150.00);


SELECT *
FROM Nota_Compra
WHERE id_cliente = 1
ORDER BY id_compra DESC;

-- calcular o valor total de uma compra --
DROP FUNCTION IF EXISTS Calcular_Total_Compra;
DELIMITER //

CREATE FUNCTION Calcular_Total_Compra (
    p_id_compra INT
)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE total DECIMAL(10,2);

    SELECT quantidade * valor
    INTO total
    FROM Nota_Compra
    WHERE id_compra = p_id_compra;

    RETURN total;
END //
DELIMITER ;

SELECT
    id_compra,
    Calcular_Total_Compra(id_compra) AS Valor_Total
FROM Nota_Compra;


